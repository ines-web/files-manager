package javaapplication1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;


public class Form_Dashboard extends javax.swing.JPanel {
     Connection con =null;
  PreparedStatement pst=null;
  ResultSet rs=null;

    public Form_Dashboard() {
        initComponents(); 
        con=DBConnection.ConnnectionDB();
        init();
       
      
    }

    private void init() { 
      

         try{

            String sql ="select * from expert  ";

            pst=con.prepareStatement(sql);
           
            rs=pst.executeQuery();
            // table.setModel(DbUtils.resultSetToTableModel(rs));
             }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Missing Data");
        }
            
                try{

            String sql ="select count(*), from expert  ";

            pst=con.prepareStatement(sql);
           
            rs=pst.executeQuery();
         String nomber =rs.getString("count(*)"); 
       //  card1.setData(new ModelCard(null, null, null, nomber, "Report Income Monthly"));
             }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Missing Data");
        }
        //  init card data
       
       // card2.setData(new ModelCard(null, null, null, "$ 800.00", "Report Expense Monthly"));
        //card3.setData(new ModelCard(null, null, null, "$ 300.00", "Report Profit Monthly"));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setOpaque(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 231, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 156, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
