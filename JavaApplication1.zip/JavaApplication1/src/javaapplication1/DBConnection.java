package javaapplication1;


import java.sql.*;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER042022
 */
public class DBConnection {
    Connection con=null;
    public static Connection ConnnectionDB(){
     try{
       Class.forName("org.sqlite.JDBC");
       Connection con = DriverManager.getConnection("jdbc:sqlite:BASE.db");
      
       return con; 
       
       }catch(Exception e){
       JOptionPane.showMessageDialog(null, e);    
        return null; 
       }
}
}