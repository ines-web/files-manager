/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication1;

/**
 *
 * @author Hyrex
 */

import com.formdev.flatlaf.FlatLightLaf;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.net.*;



public class UpdateExpert extends javax.swing.JFrame {
 Connection conn =null;
  PreparedStatement pst=null;
  ResultSet rs=null;
    /**
     * Creates new form Staff_details
     */
   public UpdateExpert() {
        try {  
    UIManager.setLookAndFeel( new FlatLightLaf() );
     
        } catch( Exception ex ) {
    System.err.println( "Failed to initialize LaF" );
}

        initComponents();
        conn= DBConnection.ConnnectionDB();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, 
        size.height/2 - getHeight()/2);
  filldom(); 
  fillSpe();
  
   /*  try{

         
 
              String sql ="select * from expert where nom="+"'"+txt_nom+"'";

            pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
                  //txt_nom.setText(sql);

                String add2 =rs.getString("Domaine");
                
                com_domaine(add2); 
                String add3 =rs.getString("Specialite");
                
                  
                  com_spe(add3);
               String add6 =rs.getString("candidatureType");
                
                com_type (add6);
                String add4 =rs.getString("Telephone");
                txt_tel.setText(add4);

                String add5 =rs.getString("Email");
                txt_email.setText(add5);

             
                
                String add9 =rs.getString("Wilaya");
                
                com_wilaya(add9);
          

                
                
                byte[] img = rs.getBytes("image");
                ImageIcon imageIcon = new ImageIcon(new ImageIcon(img).getImage().getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_SMOOTH));
                lbl_img.setIcon(imageIcon);
                
                
                

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Missing Data");
        }
        finally {

            try{

                rs.close();
                pst.close();

            }
            catch(Exception e){

            }
        }
*/
                                                         

  
  
      
   
        
    }
    
    void com_domaine (String mot)
            
    {  int i=0;
        String combo=txt_domaine.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_domaine.setSelectedIndex(i++);
      combo=txt_domaine.getSelectedItem().toString();  }
        
        
        
        
    }
    
     void com_spe (String mot)
            
    {  int i=0;
        String combo=txt_spe.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_spe.setSelectedIndex(i++);
      combo=txt_spe.getSelectedItem().toString();  }
    }
     
         void com_type (String mot)
            
    {  int i=0;
        String combo=txt_type.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_type.setSelectedIndex(i++);
      combo=txt_type.getSelectedItem().toString();  }
    }
     
        void com_wilaya (String mot)
            
    {  int i=0;
        String combo=txt_wilaya.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_wilaya.setSelectedIndex(i++);
      combo=txt_wilaya.getSelectedItem().toString();  }    
    }
    public UpdateExpert(String msg) {
        
        
      try {  
    UIManager.setLookAndFeel( new FlatLightLaf() );
     
        } catch( Exception ex ) {
    System.err.println( "Failed to initialize LaF" );
}

        initComponents();
        conn=DBConnection.ConnnectionDB();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, 
        size.height/2 - getHeight()/2);
  filldom(); 
  fillSpe();
  

          txt_nom.setText(msg);
          
            try{

         
 
              String sql ="select * from expert where nom="+"'"+msg+"'";

            pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
                  //txt_nom.setText(sql);

                String add2 =rs.getString("Domaine");
                
                com_domaine(add2); 
                String add3 =rs.getString("Specialite");
                
                  
                  com_spe(add3);
               String add6 =rs.getString("candidatureType");
                
                com_type (add6);
                String add4 =rs.getString("Telephone");
                txt_tel.setText(add4);

                String add5 =rs.getString("Email");
                txt_email.setText(add5);

             
                
                String add9 =rs.getString("Wilaya");
                
                com_wilaya(add9);
          

                
                
                byte[] img = rs.getBytes("image");
                ImageIcon imageIcon = new ImageIcon(new ImageIcon(img).getImage().getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_SMOOTH));
                lbl_img.setIcon(imageIcon);
                
                
                

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Missing Data");
        }
        finally {

            try{

                rs.close();
                pst.close();

            }
            catch(Exception e){

            }
        }

                                                         

  
  
      
   
        
    
    
          
          
          
    }
    
    
    public void fillSpe() {
        String sql="select * from spe ;";
       try{   pst=conn.prepareStatement(sql);
            
           
              rs=pst.executeQuery();
                while(rs.next()){
                    txt_spe.addItem(rs.getString("spe"));
                }
                JOptionPane.showMessageDialog(null,"Data filled successfully");

            }
            catch (Exception e) {
                JOptionPane.showMessageDialog(null,e);
            }
       finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }
    
    
   
 
    }
    public void filldom() {
        String sql="select * from Domaine ;";
       try{   pst=conn.prepareStatement(sql);
            
           
              rs=pst.executeQuery();
                while(rs.next()){
                    txt_domaine.addItem(rs.getString("dom"));
                }
                JOptionPane.showMessageDialog(null,"Data filled successfully");

            }
            catch (Exception e)

            {
                JOptionPane.showMessageDialog(null,e);
            }    
       finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }
    
    
   
 
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txt_tel = new javax.swing.JTextField();
        txt_email = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txt_nom = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txt_type = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        txt_domaine = new javax.swing.JComboBox<>();
        valuetext = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        valuetext2 = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        txt_wilaya = new javax.swing.JComboBox<>();
        txt_spe = new javax.swing.JComboBox<>();
        jSeparator1 = new javax.swing.JSeparator();
        jButton2 = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel11 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        lbl_img = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        txt_emp = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        cc = new com.mommoo.flat.button.FlatButton();
        cmd_save = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setForeground(java.awt.Color.white);
        setIconImages(null);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(0, 153, 255));
        jPanel3.setForeground(new java.awt.Color(0, 101, 153));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Contact :");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 450, -1, -1));
        jPanel3.add(txt_tel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 450, 168, -1));
        jPanel3.add(txt_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 410, 168, -1));

        jLabel6.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Email :");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, -1, -1));

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Specialité :");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 90, -1));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Domaine :");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 70, -1));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nom :");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 40, -1));

        txt_nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nomActionPerformed(evt);
            }
        });
        txt_nom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_nomKeyReleased(evt);
            }
        });
        jPanel3.add(txt_nom, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 160, 168, -1));

        jLabel8.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Wilaya :");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 490, 50, -1));

        jLabel9.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Type de Candidature :");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, 140, -1));

        txt_type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Solicité", "Non solicité" }));
        jPanel3.add(txt_type, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 370, 170, -1));
        jPanel3.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(333, 80, -1, -1));

        txt_domaine.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aucun" }));
        txt_domaine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_domaineActionPerformed(evt);
            }
        });
        jPanel3.add(txt_domaine, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 170, -1));

        valuetext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valuetextActionPerformed(evt);
            }
        });
        jPanel3.add(valuetext, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 240, 170, -1));

        jSeparator3.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 60, 20));

        valuetext2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valuetext2ActionPerformed(evt);
            }
        });
        jPanel3.add(valuetext2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 330, 170, -1));

        jButton6.setBackground(new java.awt.Color(51, 153, 0));
        jButton6.setForeground(new java.awt.Color(0, 101, 153));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Calculate.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 330, 30, 30));

        txt_wilaya.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ADRAR\t", "CHELEF\t", "LAGHOUAT\t", "OUM EL BOUAGUI\t", "BATNA\t", "BEDJAYA\t", "BISKRA\t", "BECHAR\t", "BLIDA\t", "BOUIRA\t", "TAMANRASSET\t", "TEBESSA\t", "TLEMCEN\t", "TIARET\t", "TIZI OUZOU\t", "ALGER\t", "DJELFA\t", "JIJEL\t", "SETIF\t", "SAIDA\t", "SKIKDA\t", "SIDI BEL ABBES\t", "ANNABA\t", "GUELMA\t", "CONSTANTINE\t", "MEDEA\t", "MOSTAGHANEM\t", "M'SILA\t", "MASCARA\t", "OUARGLA\t", "ORAN\t", "EL BAYADH\t", "ILLIZI\t", "BORDJ BOU ARRERIDJ\t", "BOUMERDES\t", "EL TAREF\t", "TINDOUF\t", "TISSEMSILT\t", "EL OUED\t", "KHENCHELA\t", "SOUK AHRAS\t", "TIPAZA\t", "MILA\t", "AIN DEFLA\t", "NAAMA\t", "AIN TEMOUCHENT\t", "GHARDAIA\t", "GHELIZANE\t", " " }));
        jPanel3.add(txt_wilaya, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 490, 170, -1));

        txt_spe.setEditable(true);
        txt_spe.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aucune" }));
        txt_spe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_speActionPerformed(evt);
            }
        });
        jPanel3.add(txt_spe, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 290, 170, -1));

        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 60, 20));

        jButton2.setBackground(new java.awt.Color(51, 153, 0));
        jButton2.setForeground(new java.awt.Color(0, 101, 153));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Calculate.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 240, 30, 30));

        jSeparator2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, 40, 20));

        jLabel11.setBackground(new java.awt.Color(255, 0, 0));
        jLabel11.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel11.setText("X");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 0, 30, -1));

        jButton3.setBackground(new java.awt.Color(236, 255, 255));
        jButton3.setForeground(new java.awt.Color(0, 101, 153));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/attachment-512.png"))); // NOI18N
        jButton3.setText("modifier la photo");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 160, 30));

        lbl_img.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbl_img.setText("       Aucune image");
        jPanel3.add(lbl_img, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, 140, 100));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 450, 530));

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));

        jLabel12.setBackground(new java.awt.Color(51, 51, 255));
        jLabel12.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Modifier coordonnées d'un expert");
        jPanel2.add(jLabel12);

        txt_emp.setText("emp");
        jPanel2.add(txt_emp);

        jLabel10.setText("Logged in As :");
        jPanel2.add(jLabel10);

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 40));

        jLabel4.setBackground(new java.awt.Color(255, 0, 0));
        jLabel4.setFont(new java.awt.Font("Yu Gothic UI", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("  X");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 0, 40, 40));

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 0, 40, 40));

        jButton1.setBackground(new java.awt.Color(236, 255, 255));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 101, 153));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8_erase_24px_1.png"))); // NOI18N
        jButton1.setText("Réinitilaliser");
        jButton1.setBorder(null);
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 510, 150, 50));

        cc.setBackground(new java.awt.Color(236, 255, 255));
        cc.setForeground(new java.awt.Color(0, 101, 153));
        cc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/edit-tool (1).png"))); // NOI18N
        cc.setText("Modifier les fichiers");
        cc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ccActionPerformed(evt);
            }
        });
        getContentPane().add(cc, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 510, 180, 50));

        cmd_save.setBackground(new java.awt.Color(236, 255, 255));
        cmd_save.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmd_save.setForeground(new java.awt.Color(0, 101, 153));
        cmd_save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8_add_administrator_24px.png"))); // NOI18N
        cmd_save.setText("Appliquer  les modifications");
        cmd_save.setBorder(null);
        cmd_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmd_saveActionPerformed(evt);
            }
        });
        getContentPane().add(cmd_save, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 510, 200, 50));
        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 510, -1, -1));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 500, 600, 70));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
       txt_nom.setText("");
      
        txt_tel.setText("");
   
        txt_email.setText("");
     
    
       // txt_cv.setText("");
        
        //txt_autre.setText("");
        valuetext.setText("");
    
        lbl_img.setIcon(null);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cmd_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmd_saveActionPerformed
        // TODO add your handling code here:
        int p = JOptionPane.showConfirmDialog(null, "voulez vous appliqués ses modification ?","Modification",JOptionPane.YES_NO_OPTION);
        if(p==0){
         try{
         
         String sql="update expert set nom ='"+txt_nom.getText()+"',Domaine ='"+txt_domaine.getSelectedItem().toString()+"',Specialite='"+txt_spe.getSelectedItem().toString()+"',candidatureType='"+txt_type.getSelectedItem().toString()+"',"
                        + "Email='"+txt_email.getText()+"',Telephone='"+txt_tel.getText()+"',Wilaya='"+txt_wilaya.getSelectedItem().toString()+"' where nom='"+txt_nom.getText()+"'";
           pst=conn.prepareStatement(sql);
           pst.execute();
         
         
             
         
         }
         catch(Exception e){
         JOptionPane.showMessageDialog(null, e);
         }
       finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }
         
         

            
          
    
            Date currentDate = GregorianCalendar.getInstance().getTime();
            DateFormat df = DateFormat.getDateInstance();
            String dateString = df.format(currentDate);

            Date d = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            String timeString = sdf.format(d);

            String value0 = timeString;
            String value1 = dateString;
            String val = txt_emp.getText().toString();
        
         }
        
    }//GEN-LAST:event_cmd_saveActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
  
    String sql=" insert into Domaine (dom) values (?);";
 try{
     pst=conn.prepareStatement(sql);
    pst.setString(1,valuetext.getText());
 
    pst.execute();  
    //filldom();
    txt_domaine.addItem(valuetext.getText());
    
              

            }
            catch (Exception e)

            {
                JOptionPane.showMessageDialog(null,e);
            }     
            finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }
             
     
     
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1MouseClicked

    private void txt_nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nomActionPerformed

    private void txt_speActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_speActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_speActionPerformed

    private void valuetextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valuetextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valuetextActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        
        filename =f.getAbsolutePath();
        ImageIcon imageIcon = new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_DEFAULT));
        lbl_img.setIcon(imageIcon);
      try {

            File image = new File(filename);
            FileInputStream fis = new FileInputStream (image);
            ByteArrayOutputStream bos= new ByteArrayOutputStream();
            byte[] buf = new byte[1024];

            for(int readNum; (readNum=fis.read(buf))!=-1; ){

                bos.write(buf,0,readNum);
            }
            person_image=bos.toByteArray();
        }

        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);

        }

 finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }

            try {

        
        String query = "UPDATE expert SET image=? WHERE nom=?";
        PreparedStatement statement = conn.prepareStatement(query);
        statement.setBytes(1, person_image); 
        statement.setString(2, txt_nom.getText());
        statement.executeUpdate();
        
         JOptionPane.showMessageDialog(null, "L'operation a été bien effectée");
        
                
            } catch (Exception e) {
            } finally {
                
                 try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }}

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txt_domaineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_domaineActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_domaineActionPerformed

    private void valuetext2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valuetext2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valuetext2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

 String sql=" insert into spe (spe) values (?);";
 try{
     pst=conn.prepareStatement(sql);
    pst.setString(1,valuetext2.getText());
 
    pst.execute();
                JOptionPane.showMessageDialog(null,"Data is saved successfully");

            }
            catch (Exception e)

            {
                JOptionPane.showMessageDialog(null,e);
            }     
            finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }
 //fillSpe();
 txt_spe.addItem(valuetext2.getText());
    }//GEN-LAST:event_jButton6ActionPerformed

    private void ccActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ccActionPerformed
        // TODO add your handling code here:
        
      String msg=txt_nom.getText();  
     UpdateFile f=new UpdateFile(msg);
     f.setVisible(true);
     
     setVisible(false);
    }//GEN-LAST:event_ccActionPerformed

    private void txt_nomKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nomKeyReleased
        // TODO add your handling code here:***$
  
    }//GEN-LAST:event_txt_nomKeyReleased

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        // TODO add your handling code here:
     Home1 f=new Home1();
     f.setVisible(true);
     setVisible(false);
        
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        // TODO add your handling code here:
        
     chercherexpert f=new chercherexpert(txt_nom.getText());
     f.setVisible(true);
    // f.af.setEnabled(true);
     setVisible(false);
    }//GEN-LAST:event_jLabel4MouseClicked

    
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateExpert().setVisible(true);
              
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public com.mommoo.flat.button.FlatButton cc;
    private javax.swing.JButton cmd_save;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JLabel lbl_img;
    private javax.swing.JComboBox<String> txt_domaine;
    private javax.swing.JTextField txt_email;
    private javax.swing.JLabel txt_emp;
    private javax.swing.JTextField txt_nom;
    private javax.swing.JComboBox<String> txt_spe;
    private javax.swing.JTextField txt_tel;
    private javax.swing.JComboBox<String> txt_type;
    private javax.swing.JComboBox<String> txt_wilaya;
    private javax.swing.JTextField valuetext;
    private javax.swing.JTextField valuetext2;
    // End of variables declaration//GEN-END:variables
     
    private final ImageIcon format =null;
    //strin filename
    String filename = null;
    byte[] person_image = null;
    
    private String gender;
    
    
}
