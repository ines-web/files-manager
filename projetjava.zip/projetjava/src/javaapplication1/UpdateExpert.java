/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication1;

/**
 *
 * @author Hyrex
 */

import com.formdev.flatlaf.FlatLightLaf;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.net.*;



public class UpdateExpert extends javax.swing.JFrame {
 Connection conn =null;
  PreparedStatement pst=null;
  ResultSet rs=null;
    /**
     * Creates new form Staff_details
     */
   public UpdateExpert() {
        try {  
    UIManager.setLookAndFeel( new FlatLightLaf() );
     
        } catch( Exception ex ) {
    System.err.println( "Failed to initialize LaF" );
}

        initComponents();
        conn= DBConnection.ConnnectionDB();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, 
        size.height/2 - getHeight()/2);
  filldom(); 
  fillSpe();
  
   

     
  
      
   
        
    }
  void getdata(String mot){ 
      try{

            
 
              String sql ="select * from expert where nom="+"'"+mot+"'";

            pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
                 txt_nom.setText(mot);

               String add2 =rs.getString("Domaine");
                
                com_domaine(add2); 
                String add3 =rs.getString("Specialite");
                
                  
                  com_spe(add3);
               String add6 =rs.getString("candidatureType");
                
                com_type (add6);
                String add4 =rs.getString("Telephone");
                txt_tel.setText(add4);

                String add5 =rs.getString("Email");
                txt_email.setText(add5);

             
                
                String add9 =rs.getString("Wilaya");
                
                com_wilaya(add9);
          

                
                
    
                

        }catch(Exception e){
            
        }
        finally {

            try{

                rs.close();
                pst.close();

            }
            catch(Exception e){

            }
        }
}

   void getImg (String mot){
            try{
 
              String sql ="select * from expert where nom="+"'"+mot+"'";

            pst=conn.prepareStatement(sql);
            rs=pst.executeQuery();
      
                
                
                byte[] img = rs.getBytes("image");
                ImageIcon imageIcon = new ImageIcon(new ImageIcon(img).getImage().getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_SMOOTH));
                lbl_img.setIcon(imageIcon);
                
                
                

        }catch(Exception e){
            
        }
        finally {

            try{

                rs.close();
                pst.close();

            }
            catch(Exception e){

            }
        }
       
       
   }   
    
    void com_domaine (String mot)
            
    {  int i=0;
        String combo=txt_domaine.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_domaine.setSelectedIndex(i++);
      combo=txt_domaine.getSelectedItem().toString();  }
        
        
        
        
    }
    
     void com_spe (String mot)
            
    {  int i=0;
        String combo=txt_spe.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_spe.setSelectedIndex(i++);
      combo=txt_spe.getSelectedItem().toString();  }
    }
     
         void com_type (String mot)
            
    {  int i=0;
        String combo=txt_type.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_type.setSelectedIndex(i++);
      combo=txt_type.getSelectedItem().toString();  }
    }
     
        void com_wilaya (String mot)
            
    {  int i=0;
        String combo=txt_wilaya.getSelectedItem().toString();
        while (!combo.equals(mot)){
        txt_wilaya.setSelectedIndex(i++);
      combo=txt_wilaya.getSelectedItem().toString();  }    
    }
    
       
        
        
      
        
     
    public UpdateExpert(String msg) {
        
        
      try {  
    UIManager.setLookAndFeel( new FlatLightLaf() );
     
        } catch( Exception ex ) {
    System.err.println( "Failed to initialize LaF" );
}

        initComponents();
        conn=DBConnection.ConnnectionDB();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, 
        size.height/2 - getHeight()/2);
  filldom(); 
  fillSpe();
  

          txt_nom.setText(msg);
          
           
                
             getImg(msg);
             getdata(msg);   
             
              try{
                pst.close();
                rs.close();}

            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
          
    }
    
    
    public void fillSpe() {
        String sql="select * from spe ;";
       try{   pst=conn.prepareStatement(sql);
            
           
              rs=pst.executeQuery();
                while(rs.next()){
                    txt_spe.addItem(rs.getString("spe"));
                }
              

            }
            catch (Exception e) {
                
            }
       finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }
    
    
   
 
    }
    public void filldom() {
        String sql="select * from Domaine ;";
       try{   pst=conn.prepareStatement(sql);
            
           
              rs=pst.executeQuery();
                while(rs.next()){
                    txt_domaine.addItem(rs.getString("dom"));
                }
              

            }
            catch (Exception e)

            {
              
            }    
       finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }
    
    
   
 
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        txt_emp1 = new javax.swing.JLabel();
        lbl_img = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        txt_tel = new javax.swing.JTextField();
        txt_email = new javax.swing.JTextField();
        txt_nom = new javax.swing.JTextField();
        txt_type = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        txt_domaine = new javax.swing.JComboBox<>();
        valuetext = new javax.swing.JTextField();
        valuetext2 = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        txt_wilaya = new javax.swing.JComboBox<>();
        txt_spe = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        cmd_save = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        flatButton3 = new com.mommoo.flat.button.FlatButton();
        flatButton4 = new com.mommoo.flat.button.FlatButton();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setForeground(java.awt.Color.white);
        setIconImages(null);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(0, 102, 153));
        jPanel6.setPreferredSize(new java.awt.Dimension(456, 842));

        jPanel7.setBackground(new java.awt.Color(255, 51, 51));
        jPanel7.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jPanel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel7MouseClicked(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 17)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel5.setText("Retour");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setPreferredSize(new java.awt.Dimension(406, 4));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 406, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 4, Short.MAX_VALUE)
        );

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/icons8_id_man_in_blue_shirt_80px.png"))); // NOI18N
        jLabel14.setText("Modifier un expert");

        txt_emp1.setText("emp");

        lbl_img.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbl_img.setForeground(new java.awt.Color(204, 255, 255));
        lbl_img.setText("               Aucune image");
        lbl_img.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 255, 255), 3));

        jButton3.setBackground(new java.awt.Color(236, 255, 255));
        jButton3.setForeground(new java.awt.Color(0, 101, 153));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/icons8_name_20px_1.png"))); // NOI18N
        jButton3.setText("modifier la photo");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(113, 113, 113)
                                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(1570, 1570, 1570)
                        .addComponent(txt_emp1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(129, 129, 129)
                        .addComponent(lbl_img, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jLabel14)))
                .addGap(828, 828, 828))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(txt_emp1)))
                .addGap(55, 55, 55)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(lbl_img, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(195, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 470, 700));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setForeground(new java.awt.Color(0, 101, 153));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_tel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_telKeyTyped(evt);
            }
        });
        jPanel3.add(txt_tel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 540, 168, -1));
        jPanel3.add(txt_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 630, 168, -1));

        txt_nom.setEditable(false);
        txt_nom.setBackground(new java.awt.Color(255, 255, 255));
        txt_nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nomActionPerformed(evt);
            }
        });
        txt_nom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_nomKeyReleased(evt);
            }
        });
        jPanel3.add(txt_nom, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 168, -1));

        txt_type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Solicité", "Non solicité" }));
        jPanel3.add(txt_type, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, 170, -1));
        jPanel3.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(333, 80, -1, -1));

        txt_domaine.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aucun" }));
        txt_domaine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_domaineActionPerformed(evt);
            }
        });
        jPanel3.add(txt_domaine, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 170, -1));

        valuetext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valuetextActionPerformed(evt);
            }
        });
        jPanel3.add(valuetext, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 170, -1));

        valuetext2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valuetext2ActionPerformed(evt);
            }
        });
        jPanel3.add(valuetext2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, 170, -1));

        jButton6.setBackground(new java.awt.Color(51, 153, 0));
        jButton6.setForeground(new java.awt.Color(0, 101, 153));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Calculate.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 300, 30, 30));

        txt_wilaya.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ADRAR\t", "CHELEF\t", "LAGHOUAT\t", "OUM EL BOUAGUI\t", "BATNA\t", "BEDJAYA\t", "BISKRA\t", "BECHAR\t", "BLIDA\t", "BOUIRA\t", "TAMANRASSET\t", "TEBESSA\t", "TLEMCEN\t", "TIARET\t", "TIZI OUZOU\t", "ALGER\t", "DJELFA\t", "JIJEL\t", "SETIF\t", "SAIDA\t", "SKIKDA\t", "SIDI BEL ABBES\t", "ANNABA\t", "GUELMA\t", "CONSTANTINE\t", "MEDEA\t", "MOSTAGHANEM\t", "M'SILA\t", "MASCARA\t", "OUARGLA\t", "ORAN\t", "EL BAYADH\t", "ILLIZI\t", "BORDJ BOU ARRERIDJ\t", "BOUMERDES\t", "EL TAREF\t", "TINDOUF\t", "TISSEMSILT\t", "EL OUED\t", "KHENCHELA\t", "SOUK AHRAS\t", "TIPAZA\t", "MILA\t", "AIN DEFLA\t", "NAAMA\t", "AIN TEMOUCHENT\t", "GHARDAIA\t", "GHELIZANE\t", " " }));
        jPanel3.add(txt_wilaya, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 450, 170, -1));

        txt_spe.setEditable(true);
        txt_spe.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aucune" }));
        txt_spe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_speActionPerformed(evt);
            }
        });
        jPanel3.add(txt_spe, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 170, -1));

        jButton2.setBackground(new java.awt.Color(51, 153, 0));
        jButton2.setForeground(new java.awt.Color(0, 101, 153));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Calculate.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, 30, 30));

        jLabel11.setBackground(new java.awt.Color(255, 0, 0));
        jLabel11.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel11.setText("X");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 0, 30, -1));

        cmd_save.setBackground(new java.awt.Color(236, 255, 255));
        cmd_save.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        cmd_save.setForeground(new java.awt.Color(102, 159, 255));
        cmd_save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8_renew_50px.png"))); // NOI18N
        cmd_save.setText("      Mettre à jour");
        cmd_save.setBorder(null);
        cmd_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmd_saveActionPerformed(evt);
            }
        });
        jPanel3.add(cmd_save, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 200, 60));

        jLabel10.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 102, 153));
        jLabel10.setText("Nom :");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 280, -1));

        jLabel12.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 102, 153));
        jLabel12.setText("Domaine :");
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 280, -1));

        jLabel15.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 102, 153));
        jLabel15.setText("Spécialité");
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 240, -1));

        jPanel9.setBackground(new java.awt.Color(255, 51, 51));
        jPanel9.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jPanel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel9MouseClicked(evt);
            }
        });
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel3.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 0, -1, -1));

        jLabel16.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 102, 153));
        jLabel16.setText("Type de candidature :");
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 240, -1));

        jLabel20.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 102, 153));
        jLabel20.setText("Wilaya :");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 280, -1));

        jLabel21.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 102, 153));
        jLabel21.setText("Telephone :");
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 500, 280, -1));

        jLabel22.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 102, 153));
        jLabel22.setText("E-mail :");
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 590, 280, -1));

        flatButton3.setBackground(new java.awt.Color(232, 255, 255));
        flatButton3.setForeground(new java.awt.Color(102, 159, 255));
        flatButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8_resume_50px.png"))); // NOI18N
        flatButton3.setText("Modifier les fichiers");
        flatButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                flatButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(flatButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 120, 200, 60));

        flatButton4.setBackground(new java.awt.Color(232, 255, 255));
        flatButton4.setForeground(new java.awt.Color(102, 159, 255));
        flatButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icons8_broom_50px.png"))); // NOI18N
        flatButton4.setText("      Reinitialiser");
        flatButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                flatButton4ActionPerformed(evt);
            }
        });
        jPanel3.add(flatButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 200, 200, 60));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/imgonline-com-ua-resize-bNMkUgD897AWL0vd.jpg"))); // NOI18N
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 410, 410, 260));

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel3.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 20, 50, 300));

        jPanel1.setBackground(new java.awt.Color(255, 51, 51));
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel1MouseClicked(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("X");
        jLabel17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel17MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel17);

        jPanel3.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 0, 40, 40));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 0, 670, 740));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmd_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmd_saveActionPerformed
        // TODO add your handling code here:
        int p = JOptionPane.showConfirmDialog(null, "voulez vous appliqués ses modification ?","Modification",JOptionPane.YES_NO_OPTION);
        if(p==0){
         try{
         
         String sql="update expert set nom ='"+txt_nom.getText()+"',Domaine ='"+txt_domaine.getSelectedItem().toString()+"',Specialite='"+txt_spe.getSelectedItem().toString()+"',candidatureType='"+txt_type.getSelectedItem().toString()+"',"
                        + "Email='"+txt_email.getText()+"',Telephone='"+txt_tel.getText()+"',Wilaya='"+txt_wilaya.getSelectedItem().toString()+"' where nom='"+txt_nom.getText()+"'";
           pst=conn.prepareStatement(sql);
           pst.execute();
         
         
             
          JOptionPane.showMessageDialog(null,"la modification a été bien effectuée");
         }
         catch(Exception e){
         JOptionPane.showMessageDialog(null, e);
         }
       finally{
            try{ 
                pst.close();
                rs.close();}
      
            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
       }
         
         

            
          
    
            Date currentDate = GregorianCalendar.getInstance().getTime();
            DateFormat df = DateFormat.getDateInstance();
            String dateString = df.format(currentDate);

            Date d = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            String timeString = sdf.format(d);

            String value0 = timeString;

        
         }
        
    }//GEN-LAST:event_cmd_saveActionPerformed

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        // TODO add your handling code here:
        Home1 f=new Home1();
        f.setVisible(true);
        setVisible(false);

    }//GEN-LAST:event_jLabel11MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        String sql=" insert into Domaine (dom) values (?);";
        try{
            pst=conn.prepareStatement(sql);
            pst.setString(1,valuetext.getText());

            pst.execute();
            //filldom();
            txt_domaine.addItem(valuetext.getText());

        }
        catch (Exception e)

        {
            JOptionPane.showMessageDialog(null,e);
        }
        finally{
            try{
                pst.close();
                rs.close();}

            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void txt_speActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_speActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_speActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed

        String sql=" insert into spe (spe) values (?);";
        try{
            pst=conn.prepareStatement(sql);
            pst.setString(1,valuetext2.getText());

            pst.execute();
            JOptionPane.showMessageDialog(null,"Data is saved successfully");

        }
        catch (Exception e)

        {
            JOptionPane.showMessageDialog(null,e);
        }
        finally{
            try{
                pst.close();
                rs.close();}

            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
        }
        //fillSpe();
        txt_spe.addItem(valuetext2.getText());
    }//GEN-LAST:event_jButton6ActionPerformed

    private void valuetext2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valuetext2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valuetext2ActionPerformed

    private void valuetextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valuetextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valuetextActionPerformed

    private void txt_domaineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_domaineActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_domaineActionPerformed

    private void txt_nomKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nomKeyReleased
        // TODO add your handling code here:***$

    }//GEN-LAST:event_txt_nomKeyReleased

    private void txt_nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nomActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();

        filename =f.getAbsolutePath();
        ImageIcon imageIcon = new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_DEFAULT));
        lbl_img.setIcon(imageIcon);
        try {

            File image = new File(filename);
            FileInputStream fis = new FileInputStream (image);
            ByteArrayOutputStream bos= new ByteArrayOutputStream();
            byte[] buf = new byte[1024];

            for(int readNum; (readNum=fis.read(buf))!=-1; ){

                bos.write(buf,0,readNum);
            }
            person_image=bos.toByteArray();
        }

        catch(Exception e){
            JOptionPane.showMessageDialog(null,"erreur hors du chargement de l'image");

        }

        finally{
            try{
                pst.close();
                rs.close();}

            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
        }

        try {

            String query = "UPDATE expert SET image=? WHERE nom=?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setBytes(1, person_image);
            statement.setString(2, txt_nom.getText());
            statement.executeUpdate();

            JOptionPane.showMessageDialog(null, "L'operation a été bien effectée");

        } catch (Exception e) {
        } finally {

            try{
                pst.close();
                rs.close();}

            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }}

            // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        // TODO add your handling code here:
      

            try{
                pst.close();
                rs.close();}

            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }

        
     String msg=txt_nom.getText();  
     search f=new search(msg);
     f.setVisible(true);
            f.UPDATEButton.setEnabled(true);
            f.DELETEButton.setEnabled(true);
            f.AfficherFILE.setEnabled(true);
            f.Afficherdossier.setEnabled(true);
     
     setVisible(false);
     
     
    }//GEN-LAST:event_jLabel5MouseClicked

    private void flatButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_flatButton3ActionPerformed
        // TODO add your handling code here:
    

            try{
                pst.close();
                rs.close();}

            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }

        
      String msg=txt_nom.getText();  
     Update_File f=new Update_File(msg);
     f.setVisible(true);
     
     setVisible(false);
                         
        // TODO add your handling code here:
    }//GEN-LAST:event_flatButton3ActionPerformed

    private void flatButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_flatButton4ActionPerformed
        txt_nom.setText("");

        txt_tel.setText("");

        txt_email.setText("");

        // txt_cv.setText("");

        //txt_autre.setText("");
        valuetext.setText("");

        lbl_img.setIcon(null);   // TODO add your handling code here:
    }//GEN-LAST:event_flatButton4ActionPerformed

    private void jLabel17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel17MouseClicked


            try{
                pst.close();
                rs.close();}

            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
  
     search f=new search(txt_nom.getText());
     f.setVisible(true);
    // f.af.setEnabled(true);
            f.UPDATEButton.setEnabled(true);
            f.DELETEButton.setEnabled(true);
            f.AfficherFILE.setEnabled(true);
            f.Afficherdossier.setEnabled(true);
     
     setVisible(false);
    
    
     setVisible(false);
    }//GEN-LAST:event_jLabel17MouseClicked

    private void jPanel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel9MouseClicked
        try{
                pst.close();
                rs.close();}

            catch (Exception e1) {
                JOptionPane.showMessageDialog(null,e1);
            }
        
        Home1 f=new Home1();
        f.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_jPanel9MouseClicked

    private void jPanel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel7MouseClicked
             String msg=txt_nom.getText();  
           search f=new search(msg);
            f.setVisible(true);
            f.UPDATEButton.setEnabled(true);
            f.DELETEButton.setEnabled(true);
            f.AfficherFILE.setEnabled(true);
            f.Afficherdossier.setEnabled(true);
     
     setVisible(false);
    }//GEN-LAST:event_jPanel7MouseClicked

    private void jPanel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseClicked
             String msg=txt_nom.getText();  
             search f=new search(msg);
            f.setVisible(true);
            f.UPDATEButton.setEnabled(true);
            f.DELETEButton.setEnabled(true);
            f.AfficherFILE.setEnabled(true);
            f.Afficherdossier.setEnabled(true);
     
            setVisible(false);
    }//GEN-LAST:event_jPanel1MouseClicked

    private void txt_telKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_telKeyTyped
char c = evt.getKeyChar();
if(!Character.isDigit(c))
evt.consume();        // TODO add your handling code here:
    }//GEN-LAST:event_txt_telKeyTyped

    
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateExpert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateExpert().setVisible(true);
              
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cmd_save;
    private com.mommoo.flat.button.FlatButton flatButton3;
    private com.mommoo.flat.button.FlatButton flatButton4;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lbl_img;
    private javax.swing.JComboBox<String> txt_domaine;
    private javax.swing.JTextField txt_email;
    private javax.swing.JLabel txt_emp1;
    private javax.swing.JTextField txt_nom;
    private javax.swing.JComboBox<String> txt_spe;
    private javax.swing.JTextField txt_tel;
    private javax.swing.JComboBox<String> txt_type;
    private javax.swing.JComboBox<String> txt_wilaya;
    private javax.swing.JTextField valuetext;
    private javax.swing.JTextField valuetext2;
    // End of variables declaration//GEN-END:variables
     
    private final ImageIcon format =null;
    //strin filename
    String filename = null;
    byte[] person_image = null;
    
    private String gender;
    
    
}
